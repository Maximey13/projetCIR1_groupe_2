#include "birthsArray.h"

struct BirthsPerDay* createEmptyBirthsArray(){

    struct BirthsPerDay* b = malloc(sizeof(struct BirthsPerDay));
    if(b == NULL){
        printf("Memory Allocation for Birthday struct failed\n");
        exit(EXIT_FAILURE);
    }

    for(int i=0; i < MAX_MONTHS; i++){
        for (int j = 0; j < MAX_DAYS; j++) {
            b->birthsArray[i][j] = 0;
        }
    }
    return b;
}

void updateBirthsArray(struct BirthsPerDay* b, unsigned int day, unsigned int month){

    if(month < 1 || month > MAX_MONTHS){
        printf("Le mois n'est pas valide\n");
        return;
    }

    if(day < 1 || day > MAX_DAYS){
        printf("Le jour n'est pas valide\n");
        return;
    }

    b->birthsArray[month-1][day-1] += 1;
}

int getNbBorn(struct BirthsPerDay* b, unsigned int day, unsigned int month){

    // On renvoi -1 si le mois ou le jour n'est pas valide
    if(month < 1 || month > MAX_MONTHS){
        printf("Le mois n'est pas valide\n");
        return -1;
    }
    if(day < 1 || day > MAX_DAYS){
        printf("Le jour n'est pas valide\n");
        return -1;
    }

    return b->birthsArray[month-1][day-1];
}

void deleteBirthsArray(struct BirthsPerDay** b){

    if(*b == NULL){
        return;
    }
    free(*b);
    *b = NULL;
}

void printBirthArray(struct BirthsPerDay* b) {

    for (unsigned int i=0; i<MAX_MONTHS; i++) {
        for (unsigned int j=0; j<MAX_DAYS; j++) {

            printf("%d ", b->birthsArray[i][j]);
        }
        printf("\n");
    }
}