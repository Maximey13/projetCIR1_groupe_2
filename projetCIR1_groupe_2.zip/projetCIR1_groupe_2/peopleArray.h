#ifndef PEOPLEARRAY_H
#define PEOPLEARRAY_H

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>

#define MAX_SIZE 100
#define NB_INFO 7

// Structures
struct ArrayPeople {        // Array with everybody

    unsigned int IDfirstBorn;
    unsigned int IDlastBorn;
    unsigned int nbPeople;
    struct PersonInfo** p ;
};

struct PersonInfo {         // Container for a persons information

    unsigned int id;
    unsigned int id_mom;
    unsigned int id_dad;
    char* firstName;
    char* lastName;
    char* birthday;
    char* birthRegion;
    unsigned int nbChildren;
};

// Function Prototypes
// Creation
struct ArrayPeople* createEmptyArray(unsigned int nbPeople);
struct PersonInfo* FillPersonDetails(char intel [], unsigned int n, struct PersonInfo* guy, struct ArrayPeople* everyone);

// Access
struct PersonInfo* getPerson (struct ArrayPeople* p, unsigned int id);
unsigned int numberPeople (struct ArrayPeople* p);

// Delete
void deletePerson(struct PersonInfo** p);
void deleteArrayPeople(struct ArrayPeople** people);

// Other
void printPerson (struct PersonInfo*);
void printArrayPointers (struct ArrayPeople*);
struct PersonInfo* mostChildren (struct ArrayPeople*);
void updateFirstBorn(struct ArrayPeople* people, struct PersonInfo* newPerson);
void updateLastBorn(struct ArrayPeople* people, struct PersonInfo* newPerson);
void splitBirthday(char* birthday, unsigned int* day, unsigned int* month,unsigned int* year);
void infoCounter(struct ArrayPeople* people, unsigned int* nbWMother, unsigned int* nbWFather, unsigned int* nbWBoth, unsigned int* haveChild);

// User Interaction function
unsigned int askContinue();

#endif //PEOPLEARRAY_H