#include "createWebPages.h"
#include "birthsArray.h"
#include "regionTrie.h"

void writeStartIndex(FILE* pageIndex) {
    fprintf( pageIndex, "<!DOCTYPE html>\n"
                        "<html lang=\"en\">\n"
                        "<head>\n"
                        "    <meta charset=\"UTF-8\">\n"
                        "    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n"
                        "    <title>Test</title>\n"
                        "    <script src=\"../resources/index.js\" defer></script>\n"
                        "    <link rel=\"stylesheet\" href=\"../resources/index.css\">\n"
                        "    <script src=\"https://cdn.jsdelivr.net/npm/chart.js\"></script>\n"
                        "</head>\n"
                        "\n"
                        "<body>\n"
                        "    <h1>BIENVENUE SUR GÉNÉALink</h1>\n"
                        "    <div class=\"barre\"></div>\n"
                        "    <h2>Appliquez un filtre sur les personnes</h2><br>\n"
                        "\n"
                        "    <div class=\"f\">\n"
                        "        <div id=\"content-filter\">\n"
                        "            <textarea id=\"name\" name=\"filter\" placeholder=\"Ecrivez un nom ou Prénom\" oninput=\"filter()\"></textarea>\n"
                        "            <textarea id=\"year\" name=\"filter\" placeholder=\"Ecrivez une année\" oninput=\"filter()\"></textarea>\n"
                        "            <textarea id=\"region\" name=\"filter\" placeholder=\"Ecrivez une région\" oninput=\"filter()\"></textarea>\n"
                        "        </div>\n"
                        "    </div><br><br>\n"
                        "\n"
                        "    <form>\n"
                        "        <select id=\"select\">\n"
                        "            <option value=\"\">- choisissez une personne -</option>\n"
                        "        </select>\n"
                        "    </form><br><br>\n"
                        "    \n"
                        "    <div class=\"barre\"></div>\n"
                        "    <h2>Faites apparaitre un diagramme représentant les régions en fonction de leur naissances</h2><br>\n"
                        "    <button id=\"buttonModal\" onclick=\"DisplayCharts()\">Diagramme des regions</button><br><br>\n"
                        "    \n"
                        "    <div class=\"barre\"></div>\n"
                        "    <h2>Visitez l'arbre d'une personne choisie aléatoirement</h2>\n"
                        "    <button id=\"shuffleButton\" onclick=\"shuffle()\">CLIQUEZ !</button><br>\n"
                        "    \n"
                        "<button class=\"bouton\" id=\"bouton\" onclick=\"window.location.href = 'info.html';\">\n"
                        "        <svg height=\"16\" width=\"16\" xmlns=\"http://www.w3.org/2000/svg\" version=\"1.1\" viewBox=\"0 0 1024 1024\"><path d=\"M874.690416 495.52477c0 11.2973-9.168824 20.466124-20.466124 20.466124l-604.773963 0 188.083679 188.083679c7.992021 7.992021 7.992021 20.947078 0 28.939099-4.001127 3.990894-9.240455 5.996574-14.46955 5.996574-5.239328 0-10.478655-1.995447-14.479783-5.996574l-223.00912-223.00912c-3.837398-3.837398-5.996574-9.046027-5.996574-14.46955 0-5.433756 2.159176-10.632151 5.996574-14.46955l223.019353-223.029586c7.992021-7.992021 20.957311-7.992021 28.949332 0 7.992021 8.002254 7.992021 20.957311 0 28.949332l-188.073446 188.073446 604.753497 0C865.521592 475.058646 874.690416 484.217237 874.690416 495.52477z\"></path></svg>\n"
                        "        <span>Infos</span>\n"
                        "    </button>\n"
                        "\n"
                        "    <button class=\"bouton\" id=\"bouton1\" onclick=\"window.location.href = 'query.html';\">\n"
                        "        <svg height=\"16\" width=\"16\" xmlns=\"http://www.w3.org/2000/svg\" version=\"1.1\" viewBox=\"0 0 1024 1024\"><path d=\"M874.690416 495.52477c0 11.2973-9.168824 20.466124-20.466124 20.466124l-604.773963 0 188.083679 188.083679c7.992021 7.992021 7.992021 20.947078 0 28.939099-4.001127 3.990894-9.240455 5.996574-14.46955 5.996574-5.239328 0-10.478655-1.995447-14.479783-5.996574l-223.00912-223.00912c-3.837398-3.837398-5.996574-9.046027-5.996574-14.46955 0-5.433756 2.159176-10.632151 5.996574-14.46955l223.019353-223.029586c7.992021-7.992021 20.957311-7.992021 28.949332 0 7.992021 8.002254 7.992021 20.957311 0 28.949332l-188.073446 188.073446 604.753497 0C865.521592 475.058646 874.690416 484.217237 874.690416 495.52477z\"></path></svg>\n"
                        "        <span>Query</span>\n"
                        "    </button>\n");
}

void writeIndexPeople(FILE* pageIndex, struct ArrayPeople* people) {

    unsigned int n = numberPeople(people);
    fprintf(pageIndex, "    <div id=\"everyone\">\n");

    for (unsigned int i=0; i<n; i++) {

        struct PersonInfo* p = getPerson(people, i);
        fprintf(pageIndex, "        <div class=\"people\">%s %s, %s, %s, ../export/%s_%s.html</div>\n", p->firstName, p->lastName, p->birthday, p->birthRegion, p->lastName, p->firstName);
    }

    fprintf( pageIndex, "    </div>\n");
}

void writeInfoPage(struct ArrayPeople* people, struct BirthsPerDay* b) {

    unsigned int nbWMom = 0;
    unsigned int nbWDad = 0;
    unsigned int nbWBoth = 0;
    unsigned int nbWChild = 0;
    infoCounter(people, &nbWMom, &nbWDad, &nbWBoth, &nbWChild);

    FILE *pageInfo = fopen("../export/info.html", "w");
    fprintf(pageInfo,"<!DOCTYPE html>\n"
                     "<html lang=\"fr\">\n"
                     "    <head>\n"
                     "        <meta charset=\"utf-8\">\n"
                     "        <title> index </title>\n"
                     "         <script src=\"../resources/script.js\"></script>\n"
                     "        <link href=\"../resources/info.css\" rel=\"stylesheet\" />\n"
                     "    </head>\n"
                     "    <body>\n"
                     "        <h1>BIENVENUE SUR GÉNÉALink</h1>\n"
                     "        <h2>Voici quelque information : </h2>\n"
                     "        <div id=\"bloc\">\n");
    fprintf(pageInfo,"            <p>Il y a %d personne au total</p>\n", numberPeople(people));
    fprintf(pageInfo,"            <p>%d personnes ont une mere mother connue</p>\n", nbWMom);
    fprintf(pageInfo,"            <p>%d personnes ont un pere connue</p>\n", nbWDad);
    fprintf(pageInfo,"            <p>%d personnes ont leurs deux parents connue</p>\n", nbWBoth);
    fprintf(pageInfo,"            <p>%d personnes ont au moins un enfant</p>\n", nbWChild);
    fprintf(pageInfo,"            <p>%d personnes sont née le 29 Fevrier</p>\n", b->birthsArray[1][28]);
    fprintf(pageInfo,"        </div>\n"
                     "        <button class=\"bouton\" id=\"bouton\" onclick=\"window.location.href = 'index.html';\">\n"
                     "            <svg height=\"16\" width=\"16\" xmlns=\"http://www.w3.org/2000/svg\" version=\"1.1\" viewBox=\"0 0 1024 1024\"><path d=\"M874.690416 495.52477c0 11.2973-9.168824 20.466124-20.466124 20.466124l-604.773963 0 188.083679 188.083679c7.992021 7.992021 7.992021 20.947078 0 28.939099-4.001127 3.990894-9.240455 5.996574-14.46955 5.996574-5.239328 0-10.478655-1.995447-14.479783-5.996574l-223.00912-223.00912c-3.837398-3.837398-5.996574-9.046027-5.996574-14.46955 0-5.433756 2.159176-10.632151 5.996574-14.46955l223.019353-223.029586c7.992021-7.992021 20.957311-7.992021 28.949332 0 7.992021 8.002254 7.992021 20.957311 0 28.949332l-188.073446 188.073446 604.753497 0C865.521592 475.058646 874.690416 484.217237 874.690416 495.52477z\"></path></svg>\n"
                     "            <span>Retour</span>\n"
                     "        </button>\n"
                     "    </body>\n"
                     "</html>");
    fclose(pageInfo);
}

void writeQueryPage(struct ArrayPeople* people, struct BirthsPerDay* b, struct Regions* r) {

    struct PersonInfo* firstBorn = getPerson(people,people->IDfirstBorn);
    struct PersonInfo* lastBorn = getPerson(people,people->IDlastBorn);
    struct Trie* regionMostBorn = getMostBorn(r);
    struct PersonInfo* mostKids = mostChildren(people);

    FILE *pageQuery = fopen("../export/query.html", "w");
    fprintf(pageQuery,"<!DOCTYPE html>\n"
                     "<html lang=\"fr\">\n"
                     "    <head>\n"
                     "        <meta charset=\"utf-8\">\n"
                     "        <title> index </title>\n"
                     "         <script src=\"../resources/script.js\"></script>\n"
                     "        <link href=\"../resources/info.css\" rel=\"stylesheet\" />\n"
                     "    </head>\n"
                     "    <body>\n"
                     "        <h1>BIENVENUE SUR GÉNÉALink</h1>\n"
                     "        <h2>Voici quelque information : </h2>\n"
                     "        <div id=\"bloc\">\n");
    fprintf(pageQuery,"<p>La personne la plus vielle de l'arbre est %s %s née le %s</p>\n", firstBorn->firstName, firstBorn->lastName, firstBorn->birthday);
    fprintf(pageQuery,"<p>La personne la plus Jeune de l'arbre est %s %s née le %s</p>\n", lastBorn->firstName, lastBorn->lastName, lastBorn->birthday);
    fprintf(pageQuery,"<p>La région avec le plus de naissance est %s avec %d personnes née la bas</p>\n", r->bestRegion, regionMostBorn->nbBorn);
    fprintf(pageQuery,"<p>La personne ayant eu le plus d'enfant est %s %s avec %d gosse</p>\n", mostKids->firstName, mostKids->lastName, mostKids->nbChildren);
    fprintf(pageQuery,"        </div>\n"
                     "        <button class=\"bouton\" id=\"bouton\" onclick=\"window.location.href = 'index.html';\">\n"
                     "            <svg height=\"16\" width=\"16\" xmlns=\"http://www.w3.org/2000/svg\" version=\"1.1\" viewBox=\"0 0 1024 1024\"><path d=\"M874.690416 495.52477c0 11.2973-9.168824 20.466124-20.466124 20.466124l-604.773963 0 188.083679 188.083679c7.992021 7.992021 7.992021 20.947078 0 28.939099-4.001127 3.990894-9.240455 5.996574-14.46955 5.996574-5.239328 0-10.478655-1.995447-14.479783-5.996574l-223.00912-223.00912c-3.837398-3.837398-5.996574-9.046027-5.996574-14.46955 0-5.433756 2.159176-10.632151 5.996574-14.46955l223.019353-223.029586c7.992021-7.992021 20.957311-7.992021 28.949332 0 7.992021 8.002254 7.992021 20.957311 0 28.949332l-188.073446 188.073446 604.753497 0C865.521592 475.058646 874.690416 484.217237 874.690416 495.52477z\"></path></svg>\n"
                     "            <span>Retour</span>\n"
                     "        </button>\n"
                     "    </body>\n"
                     "</html>");
    fclose(pageQuery);
}

void writePersonPage(struct PersonInfo* p, FILE* page, struct ArrayPeople* people) {

    struct PersonInfo* mom = getPerson(people,p->id_mom);
    struct PersonInfo* dad = getPerson(people,p->id_dad);
    struct PersonInfo* moms_mom = getPerson(people,mom->id_mom);
    struct PersonInfo* moms_dad = getPerson(people,mom->id_dad);
    struct PersonInfo* dads_mom = getPerson(people,dad->id_mom);
    struct PersonInfo* dads_dad = getPerson(people,dad->id_dad);

    fprintf(page, "<!DOCTYPE html>\n"
                  "<html lang=\"fr\">\n"
                  "    <head>\n"
                  "        <meta charset=\"utf-8\">\n"
                  "        <title> index </title>\n"
                  "         <script src=\"../resources/template.js\"></script>\n"
                  "        <link href=\"../resources/template.css\" rel=\"stylesheet\" />\n"
                  "    </head>\n"
                  "    <body>\n"
                  "        <h1>BIENVENUE SUR GÉNÉALink</h1>\n"
                  "        <div class=\"gen3\">\n"
                  "            <div class=\"person\" id=\"mainCharacter\" onclick=\"modal('mainCharacter')\">\n");
    fprintf(page,"                <p>%s %s</p>\n",p->lastName, p->firstName);
    fprintf(page,"                <p>%s</p>\n", p->birthday);
    fprintf(page,"                <p>%s</p>\n", p->birthRegion);
    fprintf(page,"                <p id=\"lienCache\">mettre lien</p>\n"
                 "            </div>\n"
                 "        </div>\n"
                 "        <canvas id=\"haut\" height=\"25px\" width=\"700px\"></canvas>\n"
                 "        <div class=\"gen2\">\n"
                 "            <div id=\"mom\" class=\"person\" onclick=\"modal('mom')\" >\n");
    fprintf(page,"                <p>%s %s</p>\n",mom->lastName, mom->firstName);
    fprintf(page,"                <p>%s</p>\n", mom->birthday);
    fprintf(page,"                <p>%s</p>\n", mom->birthRegion);
    fprintf(page,"                <p id=\"lienCache\">../export/%s_%s.html</p>\n",mom->lastName, mom->firstName);
    fprintf(page,"            </div>\n"
                 "            <div id=\"dad\" class=\"person\" onclick=\"modal('dad')\">\n");
    fprintf(page,"                <p>%s %s</p>\n",dad->lastName, dad->firstName);
    fprintf(page,"                <p>%s</p>\n", dad->birthday);
    fprintf(page,"                <p>%s</p>\n", dad->birthRegion);
    fprintf(page,"                <p id=\"lienCache\">../export/%s_%s.html</p>\n",dad->lastName, dad->firstName);
    fprintf(page,"            </div>\n"
                 "        </div>\n"
                 "        <div id=\"double-canvas\">\n"
                 "            <canvas id=\"bas-gauche\" height=\"25px\" width=\"350px\"></canvas>\n"
                 "            <canvas id=\"bas-droit\" height=\"25px\" width=\"350px\"></canvas>\n"
                 "        </div>\n"
                 "        <div class=\"gen1\">\n"
                 "            <div id=\"MGmom\" class=\"person\" onclick=\"modal('MGmom')\">\n");
    fprintf(page,"                <p>%s %s</p>\n",moms_mom->lastName, moms_mom->firstName);
    fprintf(page,"                <p>%s</p>\n", moms_mom->birthday);
    fprintf(page,"                <p>%s</p>\n", moms_mom->birthRegion);
    fprintf(page,"                <p id=\"lienCache\">../export/%s_%s.html</p>\n",moms_mom->lastName, moms_mom->firstName);
    fprintf(page,"            </div>\n"
                 "            <div id=\"MGdad\" class=\"person\" onclick=\"modal('MGdad')\">\n");
    fprintf(page,"                <p>%s %s</p>\n",moms_dad->lastName, moms_dad->firstName);
    fprintf(page,"                <p>%s</p>\n", moms_dad->birthday);
    fprintf(page,"                <p>%s</p>\n", moms_dad->birthRegion);
    fprintf(page,"                <p id=\"lienCache\">../export/%s_%s.html</p>\n",moms_dad->lastName, moms_dad->firstName);
    fprintf(page,"            </div>\n"
                 "            <div id=\"PGmom\" class=\"person\" onclick=\"modal('PGmom')\">\n");
    fprintf(page,"                <p>%s %s</p>\n",dads_mom->lastName, dads_mom->firstName);
    fprintf(page,"                <p>%s</p>\n", dads_mom->birthday);
    fprintf(page,"                <p>%s</p>\n", dads_mom->birthRegion);
    fprintf(page,"                <p id=\"lienCache\">../export/%s_%s.html</p>\n",dads_mom->lastName, dads_mom->firstName);
    fprintf(page,"            </div>\n"
                 "            <div id=\"PGdad\" class=\"person\" onclick=\"modal('PGdad')\">\n");
    fprintf(page,"                <p>%s %s</p>\n",dads_dad->lastName, dads_dad->firstName);
    fprintf(page,"                <p>%s</p>\n", dads_dad->birthday);
    fprintf(page,"                <p>%s</p>\n", dads_dad->birthRegion);
    fprintf(page,"                <p id=\"lienCache\">../export/%s_%s.html</p>\n",dads_dad->lastName, dads_dad->firstName);
    fprintf(page,"            </div>\n"
                 "        </div>\n"
                 "        <button id=\"afficher\"  onclick=\"afficherCarte()\">Afficher les informations <br> relative à la personne</button>\n"
                 "        <div id=\"carte\"><p></p><p></p><p></p></div>\n"
                 "        <button class=\"bouton\" id=\"bouton\" onclick=\"window.location.href = 'index.html';\">\n"
                 "            <svg height=\"16\" width=\"16\" xmlns=\"http://www.w3.org/2000/svg\" version=\"1.1\" viewBox=\"0 0 1024 1024\"><path d=\"M874.690416 495.52477c0 11.2973-9.168824 20.466124-20.466124 20.466124l-604.773963 0 188.083679 188.083679c7.992021 7.992021 7.992021 20.947078 0 28.939099-4.001127 3.990894-9.240455 5.996574-14.46955 5.996574-5.239328 0-10.478655-1.995447-14.479783-5.996574l-223.00912-223.00912c-3.837398-3.837398-5.996574-9.046027-5.996574-14.46955 0-5.433756 2.159176-10.632151 5.996574-14.46955l223.019353-223.029586c7.992021-7.992021 20.957311-7.992021 28.949332 0 7.992021 8.002254 7.992021 20.957311 0 28.949332l-188.073446 188.073446 604.753497 0C865.521592 475.058646 874.690416 484.217237 874.690416 495.52477z\"></path></svg>\n"
                 "            <span>Retour</span>\n"
                 "        </button>\n"
                 "        <div id=\"modal\">\n"
                 "            <p></p>\n"
                 "            <p></p>\n"
                 "            <p></p>\n"
                 "            <a href=""><button id=\"afficherArbre\">voir l'arbre de la personne</button></a>\n"
                 "            <button class=\"button\" onclick=\"closeModal()\">\n"
                 "                <span class=\"X\"></span>\n"
                 "                <span class=\"Y\"></span>\n"
                 "            </button>\n"
                 "        </div>\n"
                 "        <script src=\"template.js\"></script>\n"
                 "    </body>\n"
                 "</html>");
}