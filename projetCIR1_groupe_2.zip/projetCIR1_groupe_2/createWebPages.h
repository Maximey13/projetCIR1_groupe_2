#ifndef PROJETFIN_CREATEWEBPAGES_H
#define PROJETFIN_CREATEWEBPAGES_H

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include "peopleArray.h"
#include "birthsArray.h"
#include "regionTrie.h"

void writePersonPage(struct PersonInfo* p, FILE* page, struct ArrayPeople* people);
void writeStartIndex(FILE* pageIndex);
void writeIndexPeople(FILE* pageIndex, struct ArrayPeople* people);
void writeInfoPage(struct ArrayPeople* people, struct BirthsPerDay* b);
void writeQueryPage(struct ArrayPeople* people, struct BirthsPerDay* b, struct Regions* r);

#endif //PROJETFIN_CREATEWEBPAGES_H