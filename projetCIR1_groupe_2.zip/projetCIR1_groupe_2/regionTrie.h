#ifndef STRUCT_REGION_H
#define STRUCT_REGION_H

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>

#define MAX_LETTERS 27

// Structures
struct Regions {

    struct Trie* mostBorn;
    char* bestRegion;
    struct Trie* root;
};

struct Trie {

    bool isRegion;
    int nbBorn;
    struct Trie* next [MAX_LETTERS];
};

// Function Prototypes
// Creation
struct Regions* createEmptyRegions();
struct Trie* createEmptyNodeTrie();

// Access
struct Trie* getRoot(struct Regions* r);
struct Trie* getMostBorn(struct Regions* r);
char* getBestRegion(struct Regions* r);

bool isRegion(struct Trie* t, char* region);
int getNbBornRegion(struct Regions* r,char* region);

// Modify/Update
void setNewMostBorn(struct Regions* r, struct Trie* t);
void setNewBestRegion(struct Regions* r, char* newBestRegion);
void setIsRegion(struct Trie* t);
void increaseNbBorn(struct Trie* t);
void insertRegion(struct Regions* r, struct Trie* t, char* region);
void writeRegions(FILE* f, struct Trie* t, int i, char* buffer);

// Deletes
void deleteTrie(struct Trie** t);
void deleteRegion(struct Regions** r);

#endif //STRUCT_REGION_H