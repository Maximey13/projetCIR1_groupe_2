#include "peopleArray.h"

// Create Functions
struct ArrayPeople* createEmptyArray(unsigned int nbPeople) {

    // Creates the array
    struct ArrayPeople* people = malloc(sizeof(struct ArrayPeople));
    if (people == NULL) {
        printf("Malloc Error\n");
        return NULL;
    }

    // Initial conditions
    people->IDfirstBorn = 1;
    people->IDlastBorn = 1;
    people->nbPeople = nbPeople;

    // Creates an array big enough to hold one pointer for everyone
    people->p = malloc(nbPeople * sizeof(struct PersonInfo*));
    if (people->p == NULL) {
        printf("Malloc Error\n");
        return NULL;
    }

    // allocates memory for each persons "cell"
    for (unsigned int i=0; i<nbPeople; i++) {

        people->p[i] = malloc(sizeof(struct PersonInfo));
        if (people->p[i] == NULL) {
            printf("Malloc Error\n");
            return NULL;
        }

        struct PersonInfo* guy = getPerson(people, i);
        guy->nbChildren = 0;
    }

    return people;
}

struct PersonInfo* FillPersonDetails(char intel[], unsigned int n, struct PersonInfo* guy, struct ArrayPeople* people) {

    // Split the string of info
    char infoBufferArray [NB_INFO][MAX_SIZE-50];
    int charIndent = 0;
    int infoIndent = 0;

    for (unsigned int i=0; i<n; i++) {

        if (intel[i] == ',' || intel[i] == '\0') {
            infoBufferArray [infoIndent][charIndent] = '\0';
            charIndent = 0;
            infoIndent++;
        }
        else {
            infoBufferArray [infoIndent][charIndent] = intel[i];
            charIndent++;
        }
    }

    // Allocate memory for the strings
    guy->firstName = malloc(strlen(infoBufferArray[3]) + 1);
    guy->lastName = malloc(strlen(infoBufferArray[4]) + 1);
    guy->birthday = malloc(strlen(infoBufferArray[5]) + 1);
    guy->birthRegion = malloc(strlen(infoBufferArray[6]) + 1);

    if (guy->firstName == NULL || guy->lastName == NULL || guy->birthday == NULL || guy->birthRegion == NULL) {
        printf("MALLOC ERROR\n");
        return NULL;
    }

    // Fill in the persons details
    guy->id = atoi(infoBufferArray[0]);
    guy->id_dad = atoi(infoBufferArray[1]);
    guy->id_mom = atoi(infoBufferArray[2]);
    strcpy(guy->firstName,infoBufferArray[3]);
    strcpy(guy->lastName, infoBufferArray[4]);
    strcpy(guy->birthday, infoBufferArray[5]);
    strcpy(guy->birthRegion, infoBufferArray[6]);

    // Update their parents kid counter
    struct PersonInfo* dad = getPerson(people,guy->id_dad);
    dad->nbChildren++;
    struct PersonInfo* mom = getPerson(people,guy->id_mom);
    mom->nbChildren++;

    return guy;

}

// Access Functions
struct PersonInfo* getPerson (struct ArrayPeople* people, unsigned int id) {
    return people->p[id];
}

unsigned int numberPeople (struct ArrayPeople* people) {
    return people->nbPeople;
}

// Delete Functions
void deletePerson(struct PersonInfo** p) {

    // Free all the strings
    free((*p)->firstName);
    free((*p)->lastName);
    free((*p)->birthday);
    free((*p)->birthRegion);

    // Free the actual person (I promise they were treated right)
    free(*p);
    p = NULL;
}
void deleteArrayPeople(struct ArrayPeople** people) {

    unsigned int n = numberPeople(*people);

    // Free everyone
    for (unsigned int i=0; i<n; i++) {

        struct PersonInfo* p = getPerson(*people, i);
        deletePerson(&p);
    }

    // Free the peopleArray
    free((*people)->p);
    free(*people);
}

// Other Functions
void printPerson(struct PersonInfo* p) {

    printf("ID : %d\nFathers ID : %d\nMothers ID : %d\nFirst Name : %s\nLast Name : %s\nBirthday : %s\nPlace of Birth : %s\nNumber of Children : %d\n\n",p->id,p->id_dad,p->id_mom,p->firstName,p->lastName,p->birthday,p->birthRegion,p->nbChildren);
}

void printArrayPointers (struct ArrayPeople* people) {

    unsigned int n = numberPeople (people);

    printf("The different peoples id are :\n");
    for (unsigned int i=0; i<n; i++) {
        printf("%d, ", getPerson(people,i)->id);
    }
    printf("\n\n");
}

struct PersonInfo* mostChildren (struct ArrayPeople* people) {

    unsigned int n = numberPeople(people);
    struct PersonInfo* player = people->p[1];
    struct PersonInfo* indentPerson;

    // Looks for whom st has had the most children
    for (unsigned int i=1; i<n; i++) {

        indentPerson = getPerson(people, i);
        if (player->nbChildren < indentPerson->nbChildren) {
            player = indentPerson;
        }
    }
    return player;
}

void splitBirthday(char* birthday, unsigned int* day, unsigned int* month,unsigned int* year) {

    unsigned int n = strlen(birthday);
    unsigned int nbSlashFound = 0;
    unsigned int numberIndent = 0;

    char splitBirthArray [3][5];

    // Splits a birthday into the array mentioned above
    for (unsigned int i = 0; i <= n; i++) {
        if (birthday[i] == '/') {
            splitBirthArray[nbSlashFound][numberIndent] = '\0';
            numberIndent = 0;
            nbSlashFound++;
        } else {
            splitBirthArray[nbSlashFound][numberIndent] = birthday[i];
            numberIndent++;
        }
    }

    // Converts the different value for further use
    *day = atoi(splitBirthArray[0]);
    *month = atoi(splitBirthArray[1]);
    *year = atoi(splitBirthArray[2]);
}

void updateFirstBorn(struct ArrayPeople* people, struct PersonInfo* newPerson) {

    struct PersonInfo* youngest = getPerson(people,people->IDfirstBorn);

    // Converts the birthdays into usable numbers
    unsigned int youngDay = 0;
    unsigned int youngMonth = 0;
    unsigned int youngYear = 0;
    splitBirthday(youngest->birthday, &youngDay, &youngMonth, &youngYear);

    unsigned int newDay = 0;
    unsigned int newMonth = 0;
    unsigned int newYear = 0;
    splitBirthday(newPerson->birthday, &newDay, &newMonth, &newYear);

    // Compare the two and determine the younger one
    if (newYear <= youngYear) {
        if (newYear < youngYear) {
            people->IDfirstBorn = newPerson->id;
            return;
        }
        else if (newMonth <= youngMonth) {
            if(newMonth < youngMonth) {
                people->IDfirstBorn = newPerson->id;
                return;
            }
            else if (newDay < youngDay) {
                people->IDfirstBorn = newPerson->id;
                return;
            }
        }
    }
}

void updateLastBorn(struct ArrayPeople* people, struct PersonInfo* newPerson) {

    struct PersonInfo* oldest = getPerson(people,people->IDlastBorn);

    // Convert the birthday into usable numbers
    unsigned int oldDay = 0;
    unsigned int oldMonth = 0;
    unsigned int oldYear = 0;
    splitBirthday(oldest->birthday, &oldDay, &oldMonth, &oldYear);

    unsigned int newDay = 0;
    unsigned int newMonth = 0;
    unsigned int newYear = 0;
    splitBirthday(newPerson->birthday, &newDay, &newMonth, &newYear);

    // Compare the two and determine the older one
    if (newYear >= oldYear) {
        if (newYear > oldYear) {
            people->IDlastBorn = newPerson->id;
            return;
        }
        else if (newMonth >= oldMonth) {
            if(newMonth > oldMonth) {
                people->IDlastBorn = newPerson->id;
                return;
            }
            else if (newDay > oldDay) {
                people->IDlastBorn = newPerson->id;
                return;
            }
        }
    }
}

void infoCounter(struct ArrayPeople* people, unsigned int* nbWMother, unsigned int* nbWFather, unsigned int* nbWBoth, unsigned int* nbWChild) {

    unsigned int n = numberPeople(people);

    // Updates the different counters depending on each persons info
    for (unsigned int i=0; i<n; i++) {

        struct PersonInfo* p = getPerson(people, i);

        if (p->id_mom != 0) {
            *nbWMother += 1;
        }
        if (p->id_dad != 0) {
            *nbWFather += 1;
        }
        if (p->id_mom != 0 && p->id_dad != 0) {
            *nbWBoth += 1;
        }
        if (p->nbChildren <= 1) {
            *nbWChild += 1;
        }
    }
}

unsigned int askContinue() {        // Need I say more

    int choiceInt;

    printf("-------------------------------------\n"
           "Continue ?\n"
           "1 - Yes\n"
           "-------------------------------------\n"
           "What will it be :");
    do {scanf("%d", &choiceInt); } while (choiceInt != 1);

    return choiceInt;
}