#ifndef STRUCT_BIRTHSPERDAY_H
#define STRUCT_BIRTHSPERDAY_H

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>

#define MAX_MONTHS 12
#define MAX_DAYS 31

// Structures
struct BirthsPerDay {
    unsigned int birthsArray [MAX_MONTHS] [MAX_DAYS];
};

// Function Prototypes
// Creation
struct BirthsPerDay* createEmptyBirthsArray();

// Modify/Update
void updateBirthsArray(struct BirthsPerDay* b, unsigned int day, unsigned int month);

// Access
int getNbBorn(struct BirthsPerDay* b, unsigned int day, unsigned int month);

// Delete
void deleteBirthsArray(struct BirthsPerDay** b);

// Other
void printBirthArray(struct BirthsPerDay* b);

#endif //STRUCT_BIRTHSPERDAY_H