
////////////////////////////////FILTRES////////////////////////////////
//Ces fonction implémentent un filtre pour selectionner une personne selon des critères
filter();

function filter(){
    //delete all options
    let select = document.getElementById("select");
    console.log(select);
    while (select.firstChild) {
        select.removeChild(select.firstChild);
    }

    //Opiton default
    let def = document.createElement("option");
    def.textContent = "- choisissez une personne -"
    select.appendChild(def);

    let people =  document.getElementsByClassName('people');
    

    //split the array

    let txtAreaValueName = getTxt("name");
    let txtAreaValueYear = getTxt("year");
    let txtAreaValueRegion = getTxt("region");
    let index = 0;

    let txt ;

    for (let i = 0; i < people.length; i++) {
        let splitArray = people[i].textContent.split(',');
        if(splitArray[0].toLowerCase().includes(txtAreaValueName.toLowerCase()) && splitArray[1].toLowerCase().includes(txtAreaValueYear.toLowerCase()) && splitArray[index].toLowerCase().includes(txtAreaValueRegion.toLowerCase())) {
            console.log("oui");
            let option = document.createElement("option");
            option.value = splitArray[3];
            
            option.textContent = splitArray[0];
            select.appendChild(option);
        }
    }
}

//Réccupère le contenu des filtres selon le filtre
function getTxt(id){
    let txtAreaValue = document.getElementById(id).value;
    return txtAreaValue;
}

//Permet de changer le liens lorsque que l'utilisateur clique sur le prénom
document.getElementById("select").addEventListener('change',function(){
    const url = document.getElementById("select").value;
    if(url){
        window.location.href = url;
    }

})


////////////////////////////////PIE CHARTS//////////////////////////////////
function createPie(){
const pie = document.getElementById("Pie").getContext('2d');


let myPieChart = new Chart(pie, {
    type: 'pie',
    data: {
        labels: getEveryRegion(),
        datasets: [{
            label: 'My First Dataset',
            data: getEveryRegionData(),
            backgroundColor: [
                'rgba(255, 99, 132, 0.2)',
                'rgba(54, 162, 235, 0.2)',
                'rgba(255, 206, 86, 0.2)',
                'rgba(75, 192, 192, 0.2)',
                'rgba(153, 102, 255, 0.2)',
            ],
            borderColor: [
                'rgba(255, 99, 132, 1)',
                'rgba(54, 162, 235, 1)',
                'rgba(255, 206, 86, 1)',
                'rgba(75, 192, 192, 1)',
                'rgba(153, 102, 255, 1)',
            ],
            borderWidth: 1
        }]
    },
    
});
}

//Tableau contenant toutes les régions 
function getEveryRegion(){
    let everyRegion = document.getElementById('everyRegion').children;
    let array = [];
    for (let i = 0; i < everyRegion.length; i++) {
        array.push(everyRegion[i].textContent.split(',')[0]);
    }
    return array;
}

//Tableau contenant le nombre de naissance pour chaque regions
function getEveryRegionData(){
    let everyRegion = document.getElementById('everyRegion').children;
    let array = [];
    for (let i = 0; i < everyRegion.length; i++) {
        array.push(everyRegion[i].textContent.split(',')[1]);
    }
    return array;

}


//////////////////////BUTTON AND MODAL WINDOWS //////////////////////



function DisplayCharts(){
    let f = document.body.children;
    for(let i = 0; i<f.length; i++){
        f[i].style.filter = "blur(5px)";            //rendre le fond flou (voir class flou dans le html, div qui recouvre toute la page)
    }
    
    //Desactive le boutton
    document.getElementById("buttonModal").disabled = true;
    


    //Création des sections pour mettre la fenêtre modale
    let canvas = document.createElement('canvas');
    let divCanvas = document.createElement('div');
    let divContainer = document.createElement('div');
    

    //CSS divContainer
    divContainer.setAttribute('id', 'container');
    divContainer.classList.add("fondu-in");
    setTimeout( () => {
        divContainer.style.opacity = 1;           
    }, 0)
    

    divContainer.style.width = "100%";
    divContainer.style.display = "flex";
    divContainer.style.justifyContent = "center";
    divContainer.style.alignItems = "center";
    divContainer.style.position = "absolute";
    divContainer.style.zIndex = "10";
    
    


    //CSS DivCanvas
    divCanvas.setAttribute('id', 'myModal');
    divCanvas.style.width = "40%";
    divCanvas.style.display = 'flex';
    divCanvas.style.justifyContent = "center";
    divCanvas.style.alignItems = "center";
    
    

    //CSS Canvas
    canvas.setAttribute('id', 'Pie');
    canvas.style.display = "flex";
    canvas.style.justifyContent="center";
    canvas.style.alignItems="center";

    

    

    let closeButton = document.createElement("div");
    closeButton.setAttribute('class', 'button');

    let X = document.createElement("span");
    let Y = document.createElement("span");
    X.setAttribute('class', 'X');
    Y.setAttribute('class', 'Y');

    closeButton.appendChild(X);
    closeButton.appendChild(Y);

    

    

    closeButton.style.top = "1px";
    closeButton.style.right = "10px";
    closeButton.style.borderRadius = "10px";
    closeButton.style.cursor = "pointer";

    // Pour fermer la fenêtre modale quand on clique sur le bouton de fermeture
    closeButton.addEventListener("click", () => {
        divContainer.style.opacity = 0;
        document.querySelector("#container").classList.remove("fondu-in");
        document.querySelector("#container").classList.add("fondu-out");
        
        document.getElementById("buttonModal").disabled = false;
        let f = document.body.children;
        for(let i = 0; i<f.length; i++){
            f[i].style.filter = "blur(0)";          //rendre le fond normal
        }
        setTimeout( () => {
            divContainer.remove();           
        }, 1000)
    });

    document.body.firstChild.before(divContainer);
    divContainer.appendChild(divCanvas);
    divCanvas.appendChild(canvas);
    divCanvas.appendChild(closeButton);
    createPie();
}


///////////////////RANDOM Person///////////////////////

Math.random()

let max = document.getElementById("everyone").children.length;
let min = 0;

let index = Math.floor(Math.random() * (max - min) + min);

console.log(index);


function shuffle(){
    let everyoneArray = document.getElementById("everyone").children;
    const url = everyoneArray[index].textContent.split(",")[3];
    if(url){
        window.location.href = url;
    }
    

}