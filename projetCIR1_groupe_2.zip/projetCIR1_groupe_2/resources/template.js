
// Nous utilisons canvas pour dessiner des liens entre les cartes des personnes
findUnknow();
links();


function links(){

    // Lien entre le main character et ses parents

    document.addEventListener('DOMContentLoaded', (event) => {
        let canvas = document.getElementById('haut');
        
        let context = canvas.getContext('2d');
        context.beginPath();
        context.moveTo(350, 0);
        context.lineTo(350, 12);
        context.moveTo(100, 12);
        context.lineTo(600, 12);
        context.moveTo(100, 12);
        context.lineTo(100, 60);
        context.moveTo(600, 12);
        context.lineTo(600, 60);
        context.stroke();
    });

    // Lien entre les parents et les grand parent dans 2 canva different

    document.addEventListener('DOMContentLoaded', (event) => {
        let canvas = document.getElementById('bas-gauche');
        
        let context = canvas.getContext('2d');
        context.beginPath();
        context.moveTo(150, 0);
        context.lineTo(150, 12);
        context.moveTo(30, 12);
        context.lineTo(270, 12);
        context.moveTo(30, 12);
        context.lineTo(30, 25);
        context.moveTo(270, 12);
        context.lineTo(270, 25);
        context.stroke();
    });

    document.addEventListener('DOMContentLoaded', (event) => {
        let canvas = document.getElementById('bas-droit');
    
        let context = canvas.getContext('2d');
        context.beginPath();
        context.moveTo(200, 0);
        context.lineTo(200, 12);
        context.moveTo(320, 12);
        context.lineTo(80, 12);
        context.moveTo(80, 12);
        context.lineTo(80, 25);
        context.moveTo(320, 12);
        context.lineTo(320, 25);
        context.stroke();
    });
}

// fonction pour afficher la carte du main character à droite de l'écran de façon dynamique
function afficherCarte(){
    let tab=['','née le: ','À: '];
    let context2=document.getElementById("afficher");
    context2.style.display="none";
    let context=document.getElementById("carte");
    context.style.display="block";
    let context3=document.getElementById("bouton");
    context3.style.top="-101px";
    // L'utilité du tableau est ici, on avance dans le tableau comme on avance dans le DOM
    for(let i=0;i<3;i++){
        document.getElementById('carte').children[i].innerHTML=tab[i]+document.getElementById('mainCharacter').children[i].innerHTML;
    }
    
}


// fonction pour afficher un modal dynamique avec les infos de la carte sur laquel on a cliqué
function modal(id){
    // Le modal apparait lorsque l'on clique sur la carte
    let modal=document.getElementById('modal');
    
    modal.style.display="block";
    let verifyCard=document.getElementById('carte');
    if(verifyCard.style.display=='block'){
        modal.style.top='-650px';
    }

    //Animation fondu 
    modal.classList.add("fondu-in");
    setTimeout( () => {
        modal.style.opacity = 1;           
    }, 0)

    // On parcours le DOM et on ecrit ce qui est lu dans le DOM dans le modal
    for(let i=0;i<3;i++){
        document.getElementById('modal').children[i].innerHTML=document.getElementById(id).children[i].innerHTML;
    }

    //Met la bonne icone en fonction de l'ID et on met le lien correctement
    let img=document.createElement('img');
    img.id="icone";
    modal.appendChild(img);
    switch(id){
        case 'mainCharacter' :
            img.src="../resources/images/bebe.jpg";
            break;
        case 'mom' :
            img.src="../resources/images/maman.png";
            break;
        case 'dad' :
            img.src="../resources/images/papa.png";
            break;
        case 'MGmom' :
            img.src="../resources/images/mamie1.png";
            
            break;
        case 'MGdad' :
            img.src="../resources/images/papi1.png";
            break;
        case 'PGmom' :
            img.src="../resources/images/mamie2.png";
            break;
        case 'PGdad' :
            img.src="../resources/images/papi2.png";
            break;

        default :
         break;
    }


    //On met le bon lien
    document.getElementById('modal').children[3].href=document.getElementById(id).children[3].innerHTML;

    // Le bouton qui renvoie à l'arbre de la personne sur le modal n'apparait pas si la personne est inconnue ou si la personne est le main character car on est deja sur son arbre
    if(id=='mainCharacter'){
        document.getElementById('modal').children[3].style.display="none";
        document.getElementById('modal').children[4].style.top="-300px";
    }
    else{
        document.getElementById('modal').children[3].style.display = "";
        document.getElementById('modal').children[4].style.top="-340px";
    }
}



function closeModal(){ 
    // Quand on clique sur la croix le modal n'est plus afficher
    let modal=document.getElementById('modal');

    //Animation fondu out
    modal.style.opacity = 0;
    document.querySelector("#modal").classList.remove("fondu-in");
    document.querySelector("#modal").classList.add("fondu-out");
    setTimeout( () => {
        modal.style.display = "none";
        for(let i=0;i<3;i++){
            document.getElementById('modal').children[i].innerHTML='';
        }
        modal.children[5].remove();
        document.getElementById('modal').children[3].href;
        document.getElementById('modal').children[3].style.display="none";
    }, 500);
}




// Fonction qui remplace les -- des carte inconnu par 'inconnu"
function findUnknow(){
    // On crée un tableau avec toute les balise 'p'
    let all=document.getElementsByClassName("person")
    // Pour chaque balise on verifie ce qu'elle contient et on modifie si besoin 
    for(let i=0; i<all.length; i++){
        if(all[i].children[0].textContent.includes("- -")){
            all[i].innerHTML='inconnu';
            all[i+1].innerHTML='inconnu'; 
            all[i+2].innerHTML='inconnu'; 
            all[i].parentElement.removeAttribute("onclick"); //Enlève le modal 
        }
    }
}