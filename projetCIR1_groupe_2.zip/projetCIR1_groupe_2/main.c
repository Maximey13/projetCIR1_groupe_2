#include "peopleArray.h"
#include "regionTrie.h"
#include "birthsArray.h"
#include "createWebPages.h"

int main() {

    // Communication with user
    // Asks for consent
    unsigned int choiceInt = 0;
    printf("Please keep in mind that any letter will not be taken to kindly when answering to question featuring options !\n");
    printf("\nDo you wish to read a CSV file ?\n"
           "-------------------------------------\n"
           "1 - Yes\n"
           "2 - No & exit\n"
           "-------------------------------------\n"
           "What will it be :");

    do {scanf("%d", &choiceInt);} while (choiceInt > 3 || choiceInt < 1);
    if (choiceInt == 2) {
        printf("\nFair enough, have a good\n");
        return 0;
    }

    // Asks what file to read
    printf("\nWhat is the name of the CSV file you wish to use?\n"
               "(please remember to use a ../ accordingly to where you put the file)\n"
               "-------------------------------------\n");
    char fileName[100];
    do {scanf("%99s", fileName);} while (fopen(fileName,"r") == NULL);

    // Reads the CSV file
    FILE* file = fopen(fileName, "r");
    if (file == NULL) {
        printf("FILE OPEN ERROR");
        return -1;
    }

    // Create a buffer to contain each line read
    int bufferLength = MAX_SIZE;
    char buffer[bufferLength];

    // Creation of the different structures
    // peopleArray
    fgets(buffer, bufferLength, file);
    int nbPeople = atoi(buffer) + 1;
    struct ArrayPeople* people = createEmptyArray(nbPeople);
    unsigned int indent = 0;

    // regionTrie & birthsArray
    struct Regions* r = createEmptyRegions();
    struct BirthsPerDay* b = createEmptyBirthsArray();

    // Filling of the different structures
    while (fgets(buffer, bufferLength, file) != NULL) {     // Loop that will read every line of the file until the very last one

        struct PersonInfo* person = getPerson(people, indent);      // Gets pointer to the person corresponding to the line being read

        // Array People
        unsigned int length = strlen(buffer);
        buffer[length - 1] = '\0';
        FillPersonDetails(buffer, length, person, people);      // Uses the buffer to fill in all the details on the person in arrayPeople

        if (person->id != 0) {      // Excludes the person 0 so as to not break certain parameters
            // Region Trie
            insertRegion(r, getRoot(r), person->birthRegion);

            // Birthday Array
            char splitBirthday [3][5];
            unsigned int n = strlen(person->birthday);
            unsigned int nbSlashFound = 0;
            unsigned int numberIndent = 0;

            for (unsigned int i = 0; i<n; i++) {        // Does the same thing as the split function that was later implemented
                if ( person->birthday[i] == '/') {
                    splitBirthday[nbSlashFound][numberIndent] = '\0';
                    numberIndent = 0;
                    nbSlashFound++;
                }
                else {
                    splitBirthday[nbSlashFound][numberIndent] = person->birthday[i];
                    numberIndent++;
                }
            }

            unsigned int day = atoi(splitBirthday[0]);
            unsigned int month = atoi(splitBirthday[1]);
            updateBirthsArray(b, day, month);

            // Update First&Last born in ArrayPeople with the split birthday
            if (person->id != 0) {
                updateFirstBorn(people, person);
                updateLastBorn(people, person);
            }
        }

        indent++;
    }
    fclose(file);
    printf("File successfully read !");

    // Second Menu
//////////////////////////////////////////////////////////////////////////////////////////////
    while (choiceInt != 0) {
        printf("\nWhat do you want to do ?\n"
               "-------------------------------------\n"
               "0 - Exit\n"
               "1 - Show family tree info\n"
               "2 - Export HTML family tree files\n"
               "3 - Export family info files\n"
               "4 - Export all files\n"
               "5 - Query Family tree\n"
               "6 - Go back to reading files\n"
               "-------------------------------------\n"
               "What will it be :");
        do { scanf("%d", &choiceInt); } while (choiceInt > 6 || choiceInt < 0);

        // Show family tree info
        if (choiceInt == 1) {

            unsigned int nbWMom = 0;
            unsigned int nbWDad = 0;
            unsigned int nbWBoth = 0;
            unsigned int nbWChild = 0;
            infoCounter(people, &nbWMom, &nbWDad, &nbWBoth, &nbWChild);

            printf("%d people have a mother\n", nbWMom);
            printf("%d people have a father\n", nbWDad);
            printf("%d people have both\n", nbWBoth);
            printf("%d people have at least one child\n", nbWChild);
            choiceInt = askContinue();
        }

        // Write the main page otherwise known as index
        FILE* pageIndex = fopen("../export/index.html", "w");
        writeStartIndex(pageIndex);
        writeIndexPeople(pageIndex, people);

        char regionsBuffer[MAX_SIZE-50];
        fprintf(pageIndex,"\n    <div id=\"everyRegion\">\n");
        writeRegions(pageIndex, getRoot(r),0,regionsBuffer);
        fprintf(pageIndex,"    </div>\n</body>\n</html>");
        fclose(pageIndex);

        // Export HTML family tree files
        if (choiceInt == 2 || choiceInt == 4) {

            // Create everyone's HTML page
            unsigned int n = numberPeople(people);

            for (unsigned int i = 1; i<n; i++) {

                //  Write/create the page name
                struct PersonInfo *personIndent = getPerson(people, i);
                unsigned int firstNameSize = strlen(personIndent->firstName);
                unsigned int lastNameSize = strlen(personIndent->lastName);

                char *pageName = malloc(17 + firstNameSize * sizeof(char) + lastNameSize * sizeof(char));
                strcpy(pageName, "../export/");
                strcat(pageName, personIndent->lastName);
                strcat(pageName, "_");
                strcat(pageName, personIndent->firstName);
                strcat(pageName, ".html");
                pageName[firstNameSize + lastNameSize + 16] = '\0';

                // Create the html file and fill it in accordingly
                FILE *page = fopen(pageName, "w");
                writePersonPage(personIndent, page, people);
                printf(" %s %s\n", personIndent->firstName, personIndent->lastName);

                fclose(page);
                free(pageName);
            }
        }

        // Export family info files
        if (choiceInt == 3 || choiceInt == 4) {

            writeInfoPage(people, b);
        }

        // Goes back to reading files
        if (choiceInt == 6) {
            deleteArrayPeople(&people);
            deleteRegion(&r);
            deleteBirthsArray(&b);
            main();
            return 0;
        }

        // Third Menu / Query
//////////////////////////////////////////////////////////////////////////////////////////////
        if (choiceInt == 5) {

            printf("\nWhat do you want to do ?\n"
                   "-------------------------------------\n"
                   "0 - Exit\n"
                   "1 - Get the first born\n"
                   "2 - Get the last born\n"
                   "3 - Number of people born in a region\n"
                   "4 - Region with the most births\n"
                   "5 - Person with the most children\n"
                   "6 - Number of people born on a given date\n"
                   "7 - Export to HTML page\n"
                   "8 - Go back to previous menu\n"
                   "-------------------------------------\n"
                   "What will it be :");
            do { scanf("%d", &choiceInt); } while (choiceInt > 8 || choiceInt < 0);

            if (choiceInt == 0) {
                deleteArrayPeople(&people);
                deleteRegion(&r);
                deleteBirthsArray(&b);
                return 0;
            }

            // Get the first person born
            if (choiceInt == 1) {
                struct PersonInfo* youngest = getPerson(people, people->IDfirstBorn);
                printf("The first Person born was : %s %s\n", youngest->firstName, youngest->lastName);
                choiceInt = askContinue();
            }

            // Get the last born person
            if (choiceInt == 2) {
                struct PersonInfo* oldest = getPerson(people, people->IDlastBorn);
                printf("The first Person born was : %s %s\n", oldest->firstName, oldest->lastName);
                choiceInt = askContinue();
            }

            // Number of people born in a region
            if (choiceInt == 3) {

                char Buffer [50];
                printf("What region do you wish to check ?\n"
                       "-------------------------------------\n");
                do { scanf("%49s", &Buffer); } while (isRegion(r->root, Buffer));

                printf ("There has been %d births in %s\n", getNbBornRegion(r, Buffer), Buffer);
                choiceInt = askContinue();
            }

            // Region with the most births
            if (choiceInt == 4) {

                struct Trie* mBorn = r->mostBorn;

                printf("The region with the most births has had %d people born there and it is %s\n", mBorn->nbBorn, getBestRegion(r));
                choiceInt = askContinue();
            }

            // Person with the most children
            if (choiceInt == 5) {

                struct PersonInfo* naughtiest = mostChildren(people);
                printf("The person with the most children is %s %s with %d children\n", naughtiest->lastName, naughtiest->firstName, naughtiest->nbChildren);
                choiceInt = askContinue();
            }

            // Number of people born on a given date
            if (choiceInt == 6) {
                unsigned int dayChoice;
                unsigned int monthChoice;

                printf("What Day do you wish to input ?\n"
                       "-------------------------------------\n");
                do { scanf("%d", &dayChoice); } while (dayChoice > 31 || dayChoice < 1)
                    ;
                printf("What Month do you wish to input ?\n"
                       "-------------------------------------\n");
                do { scanf("%d", &monthChoice); } while (monthChoice > 31 || monthChoice < 1);

                unsigned int nbBorn = getNbBorn(b, dayChoice, monthChoice);
                printf("There has been %d people born on this day\n", nbBorn);
                choiceInt = askContinue();
            }

            // Export to HTML page
            if (choiceInt == 7) {
                writeQueryPage(people, b, r);
            }
        }
    }

    deleteArrayPeople(&people);
    deleteRegion(&r);
    deleteBirthsArray(&b);
    return 0;
}