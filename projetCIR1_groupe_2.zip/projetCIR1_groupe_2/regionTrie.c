#include "regionTrie.h"


struct Regions* createEmptyRegions(){

    struct Regions* r = malloc(sizeof(struct Regions)); //Alloue la mémoire necessaire pour la structure
    if(r == NULL){ //S'assure que la mémoire est correctement allouée
        printf("Memory Allocation for regions failed\n");
        exit(EXIT_FAILURE);
    }

    r->root = createEmptyNodeTrie();  //Initalisation des variables de la structure
    r->bestRegion = NULL;
    r->mostBorn = getRoot(r);

    return r;
}

struct Trie* createEmptyNodeTrie(){

    struct Trie* t = malloc(sizeof(struct Trie)); //Alloue la mémoire necessaire pour la structure
    if(t == NULL){ //S'assure que la mémoire est correctement allouée
        printf("Memory Allocation for trie failed\n");
        exit(EXIT_FAILURE);
    }
    t->isRegion = false;    //Initalisation des variables de la structure

    for (int i = 0; i < 27; i++) {
        t->next[i] = NULL;
    }

    t->nbBorn = 0;
    return t;
}

struct Trie* getRoot(struct Regions* r){
    return r->root;
}

struct Trie* getMostBorn(struct Regions* r){
    return r->mostBorn;
}

char* getBestRegion(struct Regions* r){
    return r->bestRegion;
}

bool isRegion(struct Trie* t, char* region){
    unsigned int n = strlen(region);
    for (int i = 0; i < n; i++) {
        if (region[i] <= 'Z' && region[i] >= 'A') {
            if (t->next[region[i] - 'A'] == NULL && region[i] != region[n-1]) {
                return false;
            }
            t=t->next[region[i] - 'A'];
        }
        else if(region[i] == ' '){
            t=t->next[26];
        }
        else {
            if (t->next[region[i] - 'a'] == NULL && region[i] != region[n-1]) {
                return false;
            }
            t=t->next[region[i] - 'a'];
        }
    }
    return t->isRegion;
}

int getNbBornRegion(struct Regions* r,char* region){
    unsigned int n = strlen(region);
    struct Trie* t = r->root;
    for (int i = 0; i < n; i++) {
        if (region[i] <= 'Z' && region[i] >= 'A') {
            //Si le caractère est une majuscule ou ne s'en préocuppe pas
            //et on passe par l'equivalent de la lettre en minuscule
            if (t->next[region[i] - 'A'] == NULL) {
                printf("Region doesnt exist\n");
                return -1;
            }
            t=t->next[region[i] - 'A'];
        }
        else if(region[i] <= 'z' && region[i] >= 'a'){
            if (t->next[region[i] - 'a'] == NULL) {
                printf("Region doesnt exist\n");
                return -1;
            }
            t=t->next[region[i] - 'a'];
        }
        else {
            if (t->next[26] == NULL) {
                printf("Region doesnt exist\n");
                return -1;
            }
            t=t->next[26];
        }
    }
    return t->nbBorn;
}

void setNewMostBorn(struct Regions* r, struct Trie* t){
    r->mostBorn = t;
}

void setNewBestRegion(struct Regions* r, char* newBestRegion){

    if(r->bestRegion != NULL){  //Si une region est déjà présente, on libère la mémoire
        free(r->bestRegion);
    }
    r->bestRegion = malloc((strlen(newBestRegion)+1)* sizeof(char)); //On alloue la mémoire pour la nouvelle région
    if(r->bestRegion == NULL){
        printf("Memory Allocation for newBestRegion failed\n");
        exit(EXIT_FAILURE);
    }
    strcpy(r->bestRegion, newBestRegion); //On modifie la région dans la strcture
}

void setIsRegion(struct Trie* t){
    t->isRegion = true;
}

void increaseNbBorn(struct Trie* t){
    t->nbBorn++;
}

void insertRegion(struct Regions* r, struct Trie* t, char* region){

    unsigned int n = strlen(region);

    //On distingue trois cas : Le caractère est une majuscule, une minusucle ou un espace
    for (int i = 0; i < n; i++) {
        char letIndent = region[i];

        if (letIndent <= 'Z' && letIndent >= 'A') {
            //Si le caractère est une majuscule ou ne s'en préocuppe pas
            //et on passe par l'equivalent de la lettre en minuscule
            if (t->next[letIndent - 'A'] == NULL) {
                t->next[letIndent - 'A'] = createEmptyNodeTrie();
                if (t->next[letIndent - 'A'] == NULL) {
                    printf("Memory Allocation for char in trie failed\n");
                    exit(EXIT_FAILURE);
                }
            }
            t=t->next[letIndent - 'A'];
        }

        else if (letIndent == ' '){
            //Si le caractère est un espace on le place en index 26 du tableau (dernière position)
            //Cette place est justement réservé aux espaces
            if (t->next[26] == NULL) {
                t->next[26] = createEmptyNodeTrie();
                if (t->next[26] == NULL) {
                    printf("Memory Allocation for char in trie failed\n");
                    exit(EXIT_FAILURE);
                }
            }
            t=t->next[26];
        }

        else {
            //Si le caractère est en minuscule on le met normalement dans le tableau
            if (t->next[letIndent - 'a'] == NULL) {
                t->next[letIndent - 'a'] = createEmptyNodeTrie();
                if (t->next[letIndent - 'a'] == NULL) {
                    printf("Memory Allocation for char in trie failed\n");
                    exit(EXIT_FAILURE);
                }
            }
            t=t->next[region[i] - 'a'];
        }
    }

    setIsRegion(t);
    increaseNbBorn(t);

    if (getMostBorn(r)->nbBorn < t->nbBorn && t->isRegion) {
        setNewMostBorn(r,t);
        setNewBestRegion(r,region);
    }
}

void deleteTrie(struct Trie** t){

    if(*t == NULL){
        return;
    }

    for(int i = 0; i < MAX_LETTERS ; i++){
        if((*t)->next[i] != NULL){
            deleteTrie(&(*t)->next[i]);
        }
    }

    free(*t);
    t = NULL;
}

void deleteRegion(struct Regions** r){

    if(*r == NULL){
        return;
    }

    if((*r)->bestRegion != NULL){
        free((*r)->bestRegion);
    }

    if((*r)->root != NULL){
        deleteTrie(&(*r)->root);
    }

    free(*r);
    r=NULL;
}

void writeRegions(FILE* f, struct Trie* t, int i, char* buffer){

    if(t == NULL){
        return;
    }

    if(t->isRegion){        // If the bool is true then a word has been saved in the buffer
        buffer[i] = '\0';
        fprintf(f,"        <div class=\"region\">%s,%d</div>\n", buffer, t->nbBorn);
    }

    for (int j = 0; j < MAX_LETTERS; j++) {
        if(t->next[j] != NULL){
            if(j == 26){
                buffer[i] = ' ';
            }
            else{
                buffer[i] = j + 'a' ;
            }
            writeRegions(f,t->next[j],i+1, buffer);
        }

    }
    buffer[i] = '\0';
}